# Task Manager REST API (task-service)

Part of the [Task Platform microservices system](../README.md). This service owns
task data and calls `notification-service` on task create/complete.

A Spring Boot backend service for managing tasks — built to demonstrate REST API design,
Spring Data JPA, layered architecture (Controller → Service → Repository), request
validation, centralized exception handling, HTTP Basic authentication, inter-service
communication, and unit/integration testing with JUnit 5.

## Stack
- Java 17
- Spring Boot 3.3 (Web, Data JPA, Validation, Security)
- H2 (in-memory, default — zero setup to run locally)
- SQL Server driver included (see "Switching to SQL Server" below)
- JUnit 5 + Mockito + MockMvc + spring-security-test
- Docker

## Authentication
All `/api/**` endpoints require HTTP Basic auth.
- Username: `apiuser`
- Password: `changeme`

(In-memory user store, BCrypt-hashed password — fine for a portfolio project;
a real deployment would back this with a proper identity provider.)

Example:
```bash
curl -u apiuser:changeme http://localhost:8080/api/tasks
```

## Project structure
```
src/main/java/com/raghul/taskmanager/
  model/        Task entity, TaskStatus enum
  repository/   Spring Data JPA repository (derived queries)
  service/      Business logic layer (also triggers notification-service calls)
  controller/   REST endpoints
  dto/          Request DTOs (kept separate from entities)
  exception/    Custom exceptions + global @RestControllerAdvice handler
  security/     Spring Security config (HTTP Basic, in-memory user)
  client/       NotificationClient - calls notification-service over REST
src/test/java/com/raghul/taskmanager/
  service/      Unit tests (Mockito - repository + notification client mocked)
  controller/   Integration-style tests (@WebMvcTest + MockMvc, real security filter chain)
```

## Running locally (H2, no setup required)
```bash
mvn spring-boot:run
```
API available at `http://localhost:8080/api/tasks` (requires Basic auth — see above).
H2 console: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:taskdb`, user: `sa`, blank password)

Note: notification-service must also be running on port 8081 for notification calls
to succeed — but task-service still works without it (it just logs a warning).

## Running with Docker
```bash
docker build -t task-service .
docker run -p 8080:8080 task-service
```
Or use `docker compose up` from the repo root to run both services together.

## Running tests
```bash
mvn test
```

## API endpoints
| Method | Endpoint                          | Description                       |
|--------|------------------------------------|------------------------------------|
| GET    | /api/tasks                        | List all tasks                    |
| GET    | /api/tasks?status=PENDING         | Filter by status                  |
| GET    | /api/tasks?search=report          | Search by title keyword           |
| GET    | /api/tasks/{id}                   | Get a single task                 |
| POST   | /api/tasks                        | Create a task (triggers notification) |
| PUT    | /api/tasks/{id}                   | Update a task (triggers notification if marked COMPLETED) |
| DELETE | /api/tasks/{id}                   | Delete a task                     |

All endpoints require HTTP Basic auth (see above).

Sample request body (POST/PUT):
```json
{
  "title": "Write report",
  "description": "Q3 summary for leadership",
  "status": "PENDING",
  "dueDate": "2026-08-01"
}
```

## Switching to SQL Server
This project ships with the `mssql-jdbc` driver and a ready `application-sqlserver.properties`
profile. To actually run against SQL Server:

1. Run SQL Server locally (Docker is easiest):
   ```bash
   docker run -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=YourStrong!Passw0rd" \
     -p 1433:1433 --name sqlserver -d mcr.microsoft.com/mssql/server:2022-latest
   ```
2. Update credentials in `application-sqlserver.properties` if you changed the password.
3. Run with the profile active:
   ```bash
   mvn spring-boot:run -Dspring-boot.run.profiles=sqlserver
   ```

Hibernate's `ddl-auto=update` will auto-create the `tasks` table — no manual schema needed.

## What this project is meant to demonstrate
- REST API design (proper status codes, resource-based URLs, request/response DTOs)
- Spring Data JPA (entity mapping, derived query methods, relational persistence)
- Layered architecture with constructor-based dependency injection
- Centralized validation and error handling (`@Valid`, `@RestControllerAdvice`)
- HTTP Basic authentication with Spring Security
- Synchronous inter-service communication (RestTemplate) with failure isolation
- Unit testing business logic in isolation (Mockito)
- Integration testing the web layer including the real security filter chain (`@WebMvcTest` + MockMvc)
- Containerization (multi-stage Dockerfile) and CI (GitHub Actions)
- A database-agnostic design that runs on H2 for dev and SQL Server for production

## Honest scope note
This is a portfolio/learning project, not a production system — auth is a single
hardcoded in-memory user (not a real identity provider), there's no pagination on
list endpoints, and inter-service calls are synchronous HTTP rather than an async
message queue. Good next additions: JWT-based auth, pagination, and replacing the
direct REST call to notification-service with a message broker for looser coupling.
