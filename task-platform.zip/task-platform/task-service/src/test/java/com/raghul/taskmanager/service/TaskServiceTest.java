package com.raghul.taskmanager.service;

import com.raghul.taskmanager.client.NotificationClient;
import com.raghul.taskmanager.dto.TaskRequest;
import com.raghul.taskmanager.exception.TaskNotFoundException;
import com.raghul.taskmanager.model.Task;
import com.raghul.taskmanager.model.TaskStatus;
import com.raghul.taskmanager.repository.TaskRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TaskServiceTest {

    @Mock
    private TaskRepository taskRepository;

    @Mock
    private NotificationClient notificationClient;

    @InjectMocks
    private TaskService taskService;

    private Task sampleTask;

    @BeforeEach
    void setUp() {
        sampleTask = new Task("Write report", "Q3 summary", TaskStatus.PENDING, LocalDate.of(2026, 8, 1));
        sampleTask.setId(1L);
    }

    @Test
    void getTaskById_returnsTask_whenTaskExists() {
        when(taskRepository.findById(1L)).thenReturn(Optional.of(sampleTask));

        Task result = taskService.getTaskById(1L);

        assertThat(result.getTitle()).isEqualTo("Write report");
        verify(taskRepository, times(1)).findById(1L);
    }

    @Test
    void getTaskById_throwsException_whenTaskDoesNotExist() {
        when(taskRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> taskService.getTaskById(99L))
                .isInstanceOf(TaskNotFoundException.class)
                .hasMessageContaining("99");
    }

    @Test
    void createTask_savesAndReturnsTask() {
        TaskRequest request = new TaskRequest();
        request.setTitle("New Task");
        request.setDescription("Details");
        request.setStatus(TaskStatus.PENDING);
        request.setDueDate(LocalDate.of(2026, 9, 1));

        when(taskRepository.save(any(Task.class))).thenAnswer(invocation -> {
            Task t = invocation.getArgument(0);
            t.setId(2L);
            return t;
        });

        Task result = taskService.createTask(request);

        assertThat(result.getId()).isEqualTo(2L);
        assertThat(result.getTitle()).isEqualTo("New Task");
        verify(taskRepository).save(any(Task.class));
    }

    @Test
    void updateTask_updatesExistingFields() {
        when(taskRepository.findById(1L)).thenReturn(Optional.of(sampleTask));
        when(taskRepository.save(any(Task.class))).thenAnswer(invocation -> invocation.getArgument(0));

        TaskRequest request = new TaskRequest();
        request.setTitle("Updated title");
        request.setDescription("Updated description");
        request.setStatus(TaskStatus.IN_PROGRESS);
        request.setDueDate(LocalDate.of(2026, 10, 1));

        Task result = taskService.updateTask(1L, request);

        assertThat(result.getTitle()).isEqualTo("Updated title");
        assertThat(result.getStatus()).isEqualTo(TaskStatus.IN_PROGRESS);
    }

    @Test
    void deleteTask_deletesTask_whenTaskExists() {
        when(taskRepository.findById(1L)).thenReturn(Optional.of(sampleTask));

        taskService.deleteTask(1L);

        verify(taskRepository, times(1)).delete(sampleTask);
    }

    @Test
    void getTasksByStatus_returnsFilteredList() {
        when(taskRepository.findByStatus(TaskStatus.PENDING)).thenReturn(List.of(sampleTask));

        List<Task> result = taskService.getTasksByStatus(TaskStatus.PENDING);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getStatus()).isEqualTo(TaskStatus.PENDING);
    }
}
