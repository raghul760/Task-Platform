package com.raghul.taskmanager.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.raghul.taskmanager.dto.TaskRequest;
import com.raghul.taskmanager.model.Task;
import com.raghul.taskmanager.model.TaskStatus;
import com.raghul.taskmanager.security.SecurityConfig;
import com.raghul.taskmanager.service.TaskService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// @WebMvcTest loads only the web layer (fast) and mocks the service - this is the
// "integration test" pattern for a controller: verifies HTTP status codes, JSON
// serialization, and validation wiring without needing a real database.
// SecurityConfig is imported so these tests exercise the real filter chain
// (HTTP Basic, CSRF disabled) rather than Spring Boot's default all-secured stub.
@WebMvcTest(TaskController.class)
@Import(SecurityConfig.class)
class TaskControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private TaskService taskService;

    @Test
    void getTasks_returns401_whenUnauthenticated() throws Exception {
        mockMvc.perform(get("/api/tasks"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser
    void getAllTasks_returns200AndList() throws Exception {
        Task task = new Task("Write report", "Q3 summary", TaskStatus.PENDING, LocalDate.of(2026, 8, 1));
        task.setId(1L);
        when(taskService.getAllTasks()).thenReturn(List.of(task));

        mockMvc.perform(get("/api/tasks"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].title").value("Write report"))
                .andExpect(jsonPath("$[0].status").value("PENDING"));
    }

    @Test
    @WithMockUser
    void createTask_returns201_whenValid() throws Exception {
        TaskRequest request = new TaskRequest();
        request.setTitle("New Task");
        request.setDescription("Details");
        request.setStatus(TaskStatus.PENDING);
        request.setDueDate(LocalDate.of(2026, 9, 1));

        Task saved = new Task("New Task", "Details", TaskStatus.PENDING, LocalDate.of(2026, 9, 1));
        saved.setId(5L);

        when(taskService.createTask(any(TaskRequest.class))).thenReturn(saved);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(5))
                .andExpect(jsonPath("$.title").value("New Task"));
    }

    @Test
    @WithMockUser
    void createTask_returns400_whenTitleIsBlank() throws Exception {
        TaskRequest request = new TaskRequest();
        request.setTitle("");                       // invalid: @NotBlank
        request.setStatus(TaskStatus.PENDING);

        mockMvc.perform(post("/api/tasks")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.fieldErrors.title").exists());
    }

    @Test
    @WithMockUser
    void getTaskById_returns404_whenTaskMissing() throws Exception {
        when(taskService.getTaskById(eq(404L)))
                .thenThrow(new com.raghul.taskmanager.exception.TaskNotFoundException(404L));

        mockMvc.perform(get("/api/tasks/404"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value("Task not found with id: 404"));
    }

    @Test
    @WithMockUser
    void deleteTask_returns204() throws Exception {
        mockMvc.perform(delete("/api/tasks/1"))
                .andExpect(status().isNoContent());
    }
}
