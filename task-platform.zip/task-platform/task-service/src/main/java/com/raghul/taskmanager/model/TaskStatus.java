package com.raghul.taskmanager.model;

public enum TaskStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED
}
