package com.raghul.taskmanager.repository;

import com.raghul.taskmanager.model.Task;
import com.raghul.taskmanager.model.TaskStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface TaskRepository extends JpaRepository<Task, Long> {

    // Derived query - Spring Data JPA generates the SQL/T-SQL automatically
    List<Task> findByStatus(TaskStatus status);

    List<Task> findByTitleContainingIgnoreCase(String keyword);
}
