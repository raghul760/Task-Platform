package com.raghul.taskmanager.service;

import com.raghul.taskmanager.client.NotificationClient;
import com.raghul.taskmanager.dto.TaskRequest;
import com.raghul.taskmanager.exception.TaskNotFoundException;
import com.raghul.taskmanager.model.Task;
import com.raghul.taskmanager.model.TaskStatus;
import com.raghul.taskmanager.repository.TaskRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    private final TaskRepository taskRepository;
    private final NotificationClient notificationClient;

    // Constructor injection (preferred over field injection - testable, immutable)
    public TaskService(TaskRepository taskRepository, NotificationClient notificationClient) {
        this.taskRepository = taskRepository;
        this.notificationClient = notificationClient;
    }

    public List<Task> getAllTasks() {
        return taskRepository.findAll();
    }

    public Task getTaskById(Long id) {
        return taskRepository.findById(id)
                .orElseThrow(() -> new TaskNotFoundException(id));
    }

    public List<Task> getTasksByStatus(TaskStatus status) {
        return taskRepository.findByStatus(status);
    }

    public List<Task> searchTasksByTitle(String keyword) {
        return taskRepository.findByTitleContainingIgnoreCase(keyword);
    }

    public Task createTask(TaskRequest request) {
        Task task = new Task(
                request.getTitle(),
                request.getDescription(),
                request.getStatus(),
                request.getDueDate()
        );
        Task saved = taskRepository.save(task);
        // Cross-service call: task-service tells notification-service a task was created.
        notificationClient.notify(saved.getId(), "Task #" + saved.getId() + " created: " + saved.getTitle());
        return saved;
    }

    public Task updateTask(Long id, TaskRequest request) {
        Task existing = getTaskById(id);
        TaskStatus previousStatus = existing.getStatus();

        existing.setTitle(request.getTitle());
        existing.setDescription(request.getDescription());
        existing.setStatus(request.getStatus());
        existing.setDueDate(request.getDueDate());
        Task saved = taskRepository.save(existing);

        if (previousStatus != saved.getStatus() && saved.getStatus() == TaskStatus.COMPLETED) {
            notificationClient.notify(saved.getId(), "Task #" + saved.getId() + " marked COMPLETED");
        }
        return saved;
    }

    public void deleteTask(Long id) {
        Task existing = getTaskById(id);
        taskRepository.delete(existing);
    }
}
