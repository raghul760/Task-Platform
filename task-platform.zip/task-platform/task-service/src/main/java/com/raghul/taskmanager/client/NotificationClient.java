package com.raghul.taskmanager.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

// task-service calls notification-service over HTTP - two independently deployable
// services, each owning its own database, communicating via a REST contract.
// Failure is isolated: if notification-service is down, task creation still succeeds
// (the notification call is fire-and-forget with a caught exception), which is the
// resilience pattern real microservices need - one service's outage shouldn't
// cascade and break the other.
@Component
public class NotificationClient {

    private static final Logger log = LoggerFactory.getLogger(NotificationClient.class);

    private final RestTemplate restTemplate;
    private final String notificationServiceUrl;

    public NotificationClient(RestTemplate restTemplate,
                               @Value("${notification.service.url}") String notificationServiceUrl) {
        this.restTemplate = restTemplate;
        this.notificationServiceUrl = notificationServiceUrl;
    }

    public void notify(Long taskId, String message) {
        try {
            Map<String, Object> payload = Map.of(
                    "sourceTaskId", taskId,
                    "message", message
            );
            restTemplate.postForEntity(notificationServiceUrl + "/api/notifications", payload, Void.class);
        } catch (RestClientException ex) {
            // Don't let a downstream outage fail the primary task operation.
            log.warn("notification-service unreachable, continuing without notification: {}", ex.getMessage());
        }
    }
}
