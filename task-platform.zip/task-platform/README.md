# Task Platform — Microservices

A small but real microservices system: two independently deployable Spring Boot
services that communicate over REST, each owning its own database, coordinated
locally with Docker Compose and built via GitHub Actions CI.

```
┌─────────────────┐          POST /api/notifications          ┌────────────────────────┐
│   task-service    │ ───────────────────────────────────────▶ │  notification-service    │
│   (port 8080)      │                                            │   (port 8081)             │
│   Secured: HTTP     │                                            │                             │
│   Basic auth        │                                            │                             │
│   DB: SQL Server /  │                                            │   DB: H2 (own store)       │
│   H2 (own store)    │                                            │                             │
└─────────────────┘                                            └────────────────────────┘
```

## Services

### task-service
The primary API — full CRUD on tasks. Secured with Spring Security (HTTP Basic).
On task creation and on completion, it calls notification-service. If
notification-service is unreachable, task-service logs a warning and continues —
one service's outage doesn't cascade into the other. See
[`task-service/README.md`](task-service/README.md) for endpoint details.

### notification-service
A lightweight, independent service that receives and stores task events. It has
its own database (H2, isolated from task-service's data) and its own REST API.
It doesn't know or care how task-service is implemented — only the JSON contract
they agree on.

## Why this counts as "microservices" and not just "two apps"
- **Independent deployability** — each has its own `pom.xml`, `Dockerfile`, and can be
  built/deployed on its own schedule.
- **Independent data ownership** — no shared database or shared JPA entities between
  them; they never query each other's tables directly.
- **Network-based communication** — task-service calls notification-service over HTTP,
  not via a shared Java method call or library.
- **Failure isolation** — notification-service going down doesn't break task creation
  (caught exception + log, not a thrown error).
- **Independent CI** — the GitHub Actions workflow builds and tests each service
  separately.

## Running everything locally
```bash
docker compose up --build
```
- task-service: `http://localhost:8080/api/tasks` (Basic auth: `apiuser` / `changeme`)
- notification-service: `http://localhost:8081/api/notifications`

Or run each service individually with `mvn spring-boot:run` inside its own folder
(see each service's README for details) — useful when actively developing one service.

## CI
`.github/workflows/ci.yml` builds and runs the full test suite for both services on
every push and pull request to `main`.

## Honest scope note
This is a learning/portfolio project sized to demonstrate the pattern, not a
production system. It's two services, not twelve; there's no API gateway, no
service discovery/registry, no message broker (calls are direct HTTP, not async
via a queue), and no distributed tracing. Realistic next steps if extending it:
replace the direct REST call with an async message queue (RabbitMQ/Kafka) for
looser coupling, add an API gateway in front of both services, and add
centralized logging/tracing (e.g. Zipkin) across service calls.
