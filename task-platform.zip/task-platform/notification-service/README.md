# Notification Service

Part of the [Task Platform microservices system](../README.md). Receives and stores
task event notifications sent by `task-service` — completely independent database,
independent deployment, independent test suite.

## Stack
Java 17, Spring Boot 3.3 (Web, Data JPA, Validation), H2, JUnit 5, MockMvc, Docker.

## Running locally
```bash
mvn spring-boot:run
```
Runs on `http://localhost:8081`.

## Running with Docker
```bash
docker build -t notification-service .
docker run -p 8081:8081 notification-service
```

## Running tests
```bash
mvn test
```

## API endpoints
| Method | Endpoint                     | Description                          |
|--------|-------------------------------|----------------------------------------|
| GET    | /api/notifications            | List all notifications                |
| GET    | /api/notifications/task/{id}  | List notifications for a specific task |
| POST   | /api/notifications            | Create a notification (called by task-service) |

Sample request body (POST):
```json
{
  "sourceTaskId": 5,
  "message": "Task #5 marked COMPLETED"
}
```

## Honest scope note
No auth on this service yet (task-service is the one demonstrating the auth layer
for this platform) — a real deployment would secure service-to-service calls too,
typically with mutual TLS or a shared service-account token rather than end-user
credentials.
