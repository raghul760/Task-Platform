package com.raghul.notificationservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.raghul.notificationservice.model.Notification;
import com.raghul.notificationservice.repository.NotificationRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(NotificationController.class)
class NotificationControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private NotificationRepository notificationRepository;

    @Test
    void createNotification_returns201() throws Exception {
        NotificationRequest request = new NotificationRequest();
        request.setSourceTaskId(1L);
        request.setMessage("Task #1 marked COMPLETED");

        Notification saved = new Notification(1L, "Task #1 marked COMPLETED");
        saved.setId(10L);

        when(notificationRepository.save(any(Notification.class))).thenReturn(saved);

        mockMvc.perform(post("/api/notifications")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(10))
                .andExpect(jsonPath("$.sourceTaskId").value(1));
    }

    @Test
    void createNotification_returns400_whenMessageBlank() throws Exception {
        NotificationRequest request = new NotificationRequest();
        request.setSourceTaskId(1L);
        request.setMessage("");

        mockMvc.perform(post("/api/notifications")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest());
    }

    @Test
    void getNotificationsForTask_returnsFilteredList() throws Exception {
        Notification n = new Notification(3L, "Task #3 created");
        n.setId(7L);
        when(notificationRepository.findBySourceTaskId(3L)).thenReturn(List.of(n));

        mockMvc.perform(get("/api/notifications/task/3"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].sourceTaskId").value(3));
    }
}
