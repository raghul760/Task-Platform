package com.raghul.notificationservice.controller;

import com.raghul.notificationservice.model.Notification;
import com.raghul.notificationservice.repository.NotificationRepository;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// This is the service-to-service contract: task-service calls this endpoint
// whenever a task is created or its status changes. Each service owns its own
// data store - notification-service never touches task-service's database.
@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationRepository notificationRepository;

    public NotificationController(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    @GetMapping
    public ResponseEntity<List<Notification>> getAllNotifications() {
        return ResponseEntity.ok(notificationRepository.findAll());
    }

    @GetMapping("/task/{taskId}")
    public ResponseEntity<List<Notification>> getNotificationsForTask(@PathVariable Long taskId) {
        return ResponseEntity.ok(notificationRepository.findBySourceTaskId(taskId));
    }

    @PostMapping
    public ResponseEntity<Notification> createNotification(@Valid @RequestBody NotificationRequest request) {
        Notification saved = notificationRepository.save(
                new Notification(request.getSourceTaskId(), request.getMessage())
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }
}
